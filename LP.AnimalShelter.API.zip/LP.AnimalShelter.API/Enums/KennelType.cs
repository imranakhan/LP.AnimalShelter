﻿namespace LP.AnimalShelter.API.Enums
{
    public enum KennelType
    {
        Small = 0,
        Medium = 1,
        Large = 2
    }
}
